package com.huawei.mymusicplayer.fragment.layoutfragment;

import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import com.huawei.hms.api.bean.HwAudioPlayItem;
import com.huawei.mymusicplayer.PopCategoryActivity;
import com.huawei.mymusicplayer.R;
import com.huawei.mymusicplayer.sdk.ModelAudio;
import com.huawei.mymusicplayer.ui.BaseUIFragment;
import com.huawei.mymusicplayer.utils.ViewUtils;

import java.util.ArrayList;
import java.util.List;

public class ListFragment extends BaseUIFragment {
    private String TAG = "ListFragment";
    protected View view;
    private List<HwAudioPlayItem> mSongs = null;
    public static ListFragment newInstance() {
        return new ListFragment();
    }
    ArrayList<ModelAudio> audioArrayList;

    @Override
    public void onActivityCreated(@Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        Log.i(TAG, "Activity created !");
    }
    @Override
    protected int getContentViewLayout() {
        return R.layout.fragment_list;
    }
    @Override
    protected void initViews(View view) {
        CardView popCategory = ViewUtils.findViewById(view, R.id.popCategory);
        popCategory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i(TAG, "Pop Category started");
                Intent intent = new Intent(v.getContext(), PopCategoryActivity.class);
                startActivity(intent);
            }
        });
    }
}