package com.huawei.mymusicplayer;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PopCategoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pop_category);
    }
}